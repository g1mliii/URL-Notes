# Reviewer Notes - Anchored Firefox Extension v1.18

## Quick Start for Reviewers

This extension requires **NO BUILD PROCESS**. The source code is the exact code that runs in the browser.

### To Verify:
1. Run the build script: `./build.sh` (macOS/Linux) or `.\build.ps1` (Windows)
2. Compare the generated ZIP with the submitted extension
3. All files are identical - no compilation or transformation occurs

## What Changed in v1.18

### Files Modified:
1. **extension-firefox/lib/api.js** (Lines ~418-425, ~446-451)
   - Added `needsReauth` flag setting when refresh token is missing or invalid
   - Uses browser-agnostic storage API

2. **extension-firefox/popup/popup.js** (Lines ~320, ~1000-1015)
   - Added `checkReauthRequired()` method to detect expired sessions
   - Shows toast notification to guide users to re-authenticate
   - Called during popup initialization

3. **extension-firefox/manifest.json**
   - Version bumped from 1.16 to 1.18

### Why These Changes?
Previously, when a user's session expired (refresh token became invalid), they would be silently logged out without any notification. This caused confusion as users didn't know why they were suddenly logged out.

Now, when the session expires:
1. The system detects the expired/invalid refresh token
2. Sets a `needsReauth` flag in browser storage
3. On next popup open, shows a friendly toast: "Authentication expired. Go to Settings to sign in again."
4. User knows exactly what happened and what to do

## Architecture Overview

### No Build System
- **Pure vanilla JavaScript** - No TypeScript, Babel, Webpack, or any transpilation
- **No dependencies** - All code is self-contained
- **Direct execution** - Browser runs the code as-is
- **Easy review** - What you see is what runs

### Key Technologies
- **Manifest V2** - Firefox standard
- **IndexedDB** - Local storage
- **Supabase** - Backend (optional, for premium features)
- **Web Crypto API** - Client-side encryption

### Privacy & Security
- **Local-first** - Works completely offline
- **Zero-knowledge encryption** - Server never sees unencrypted data
- **No tracking** - No analytics or telemetry
- **No external scripts** - All code is bundled

## Testing the Changes

### Manual Test:
1. Load the extension in Firefox
2. Open browser console (F12)
3. Run: `browser.storage.local.set({ needsReauth: true })`
4. Close and reopen the extension popup
5. You should see the toast notification

### Expected Behavior:
- Toast appears with message: "Authentication expired. Go to Settings to sign in again."
- Toast auto-dismisses after ~2 seconds
- Flag is cleared after showing (won't show again)

## Permissions Used

All permissions are unchanged from v1.16:
- `storage` - Local data persistence
- `activeTab` - Current tab context
- `tabs` - Tab information for note context
- `alarms` - Periodic sync scheduling
- `contextMenus` - Right-click menu integration
- `identity` - OAuth authentication
- `notifications` - User notifications
- `<all_urls>` - Content script injection for highlighting

## External Connections

The extension connects to:
- `https://kqjcorjjvunmyrnzvqgr.supabase.co` - Backend API (premium features only)
- All connections use HTTPS
- No data sent without user authentication
- All user content is encrypted before transmission

## Support

For any questions during review:
- Email: support@anchored.site
- Website: https://anchored.site

Thank you for reviewing Anchored!
