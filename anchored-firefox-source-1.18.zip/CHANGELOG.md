# Changelog - Anchored Firefox Extension

## Version 1.18 (2025-10-22)

### Added
- Session expiration detection and handling
- User-friendly notification when authentication expires
- Automatic session cleanup on token expiration

### Changed
- Improved error handling for expired refresh tokens
- Enhanced authentication flow with better user feedback
- Browser-agnostic storage API usage for better compatibility

### Fixed
- Users are now properly notified when their session expires
- Clear guidance provided to re-authenticate via Settings
- Prevents silent logout without user awareness

## Version 1.16 (Previous)

### Features
- Domain and page-specific note-taking
- Text highlighting and selection capture
- Multi-highlight support
- Cloud sync for premium users
- Local-first architecture with offline support
- Client-side encryption for cloud storage
- Glassmorphism UI design
- AI-powered features (premium)
- Export/import functionality
- Version history tracking

### Technical
- Manifest V2 for Firefox compatibility
- IndexedDB for local storage
- Supabase backend integration
- Zero-knowledge encryption architecture
