# Anchored Firefox Extension Build Script
# Version 1.18
# This script creates a production-ready ZIP file for Firefox Add-ons submission

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Anchored Firefox Extension Builder v1.18" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if extension-firefox directory exists
if (-not (Test-Path "extension-firefox")) {
    Write-Host "ERROR: extension-firefox directory not found!" -ForegroundColor Red
    Write-Host "Please run this script from the source code root directory." -ForegroundColor Red
    exit 1
}

# Verify manifest.json exists and has correct version
$manifestPath = "extension-firefox/manifest.json"
if (-not (Test-Path $manifestPath)) {
    Write-Host "ERROR: manifest.json not found!" -ForegroundColor Red
    exit 1
}

$manifest = Get-Content $manifestPath -Raw | ConvertFrom-Json
$version = $manifest.version

Write-Host "Building Anchored Firefox Extension v$version..." -ForegroundColor Green
Write-Host ""

# Define output file
$outputFile = "anchored-firefox-$version.zip"

# Remove existing build if present
if (Test-Path $outputFile) {
    Write-Host "Removing existing build: $outputFile" -ForegroundColor Yellow
    Remove-Item $outputFile -Force
}

# Create ZIP archive with only necessary files
Write-Host "Creating ZIP archive..." -ForegroundColor Green
try {
    Compress-Archive -Path `
        extension-firefox/assets, `
        extension-firefox/background, `
        extension-firefox/content, `
        extension-firefox/lib, `
        extension-firefox/popup, `
        extension-firefox/manifest.json `
        -DestinationPath $outputFile `
        -CompressionLevel Optimal `
        -Force

    Write-Host ""
    Write-Host "========================================" -ForegroundColor Green
    Write-Host "BUILD SUCCESSFUL!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Green
    Write-Host ""
    
    # Display file info
    $fileInfo = Get-Item $outputFile
    $fileSizeKB = [math]::Round($fileInfo.Length / 1KB, 2)
    
    Write-Host "Output file: $outputFile" -ForegroundColor Cyan
    Write-Host "File size: $fileSizeKB KB" -ForegroundColor Cyan
    Write-Host "Version: $version" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "The extension is ready for submission to Firefox Add-ons!" -ForegroundColor Green
    
} catch {
    Write-Host ""
    Write-Host "ERROR: Build failed!" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
