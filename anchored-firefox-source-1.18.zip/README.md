# Anchored Firefox Extension - Source Code v1.18

## Build Instructions

This document provides step-by-step instructions to build the Anchored Firefox extension from source code.

## Prerequisites

### Operating System
- Windows 10/11, macOS 10.14+, or Linux (Ubuntu 20.04+)
- Any OS that supports Node.js and standard command-line tools

### Required Software
- **No build tools required** - This extension uses vanilla JavaScript with no compilation or bundling
- A file archiving tool (built into most operating systems)
  - Windows: Built-in PowerShell `Compress-Archive`
  - macOS/Linux: Built-in `zip` command

## Build Process

### Option 1: Automated Build (Recommended)

#### Windows
```powershell
.\build.ps1
```

#### macOS/Linux
```bash
chmod +x build.sh
./build.sh
```

This will create `anchored-firefox-1.18.zip` in the current directory.

### Option 2: Manual Build

1. **Verify Source Files**
   
   Ensure the following directories and files are present:
   ```
   extension-firefox/
   ├── assets/
   ├── background/
   ├── content/
   ├── lib/
   ├── popup/
   └── manifest.json
   ```

2. **Create ZIP Archive**

   **Windows (PowerShell):**
   ```powershell
   Compress-Archive -Path extension-firefox/assets,extension-firefox/background,extension-firefox/content,extension-firefox/lib,extension-firefox/popup,extension-firefox/manifest.json -DestinationPath anchored-firefox-1.18.zip -Force
   ```

   **macOS/Linux:**
   ```bash
   cd extension-firefox
   zip -r ../anchored-firefox-1.18.zip assets background content lib popup manifest.json
   cd ..
   ```

3. **Verify Build**
   
   The resulting `anchored-firefox-1.18.zip` should be approximately 500-520 KB in size.

## Architecture Notes

### No Build System
This extension is built using **vanilla JavaScript** with no transpilation, bundling, or compilation steps. The code runs directly in the browser without any build process.

### Why No Build Tools?
- **Simplicity**: Direct browser execution without complexity
- **Security**: Reviewers can inspect the exact code that runs
- **Performance**: No build overhead or bundle bloat
- **Compatibility**: Works across all modern browsers without tooling

### File Structure
- `manifest.json` - Firefox Manifest V2 configuration
- `assets/` - Icons and static resources
- `background/` - Background scripts for extension lifecycle
- `content/` - Content scripts injected into web pages
- `lib/` - Shared libraries (API client, storage, sync, encryption)
- `popup/` - Extension popup UI (HTML, CSS, JavaScript)

## Verification

To verify the build matches the submitted extension:

1. Extract `anchored-firefox-1.18.zip`
2. Compare file contents with the source in `extension-firefox/`
3. All files should be identical (no modifications during build)

## Version Information

- **Version**: 1.18
- **Manifest Version**: 2 (Firefox)
- **Build Date**: 2025-10-22

## Changes in v1.18

- Added session expiration handling
- Improved authentication error messages
- User-friendly re-login prompts when session expires

## Support

For questions about the build process or source code:
- Website: https://anchored.site
- Email: support@anchored.site

## License

Copyright © 2025 Anchored. All rights reserved.
