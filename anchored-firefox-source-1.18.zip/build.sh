#!/bin/bash
# Anchored Firefox Extension Build Script
# Version 1.18
# This script creates a production-ready ZIP file for Firefox Add-ons submission

echo "========================================"
echo "Anchored Firefox Extension Builder v1.18"
echo "========================================"
echo ""

# Check if extension-firefox directory exists
if [ ! -d "extension-firefox" ]; then
    echo "ERROR: extension-firefox directory not found!"
    echo "Please run this script from the source code root directory."
    exit 1
fi

# Verify manifest.json exists
MANIFEST_PATH="extension-firefox/manifest.json"
if [ ! -f "$MANIFEST_PATH" ]; then
    echo "ERROR: manifest.json not found!"
    exit 1
fi

# Extract version from manifest.json
VERSION=$(grep -o '"version": "[^"]*' "$MANIFEST_PATH" | cut -d'"' -f4)

echo "Building Anchored Firefox Extension v$VERSION..."
echo ""

# Define output file
OUTPUT_FILE="anchored-firefox-$VERSION.zip"

# Remove existing build if present
if [ -f "$OUTPUT_FILE" ]; then
    echo "Removing existing build: $OUTPUT_FILE"
    rm -f "$OUTPUT_FILE"
fi

# Create ZIP archive with only necessary files
echo "Creating ZIP archive..."
cd extension-firefox

if zip -r "../$OUTPUT_FILE" \
    assets \
    background \
    content \
    lib \
    popup \
    manifest.json \
    -x "*.DS_Store" "*.git*" "*node_modules*" "*.log"; then
    
    cd ..
    
    echo ""
    echo "========================================"
    echo "BUILD SUCCESSFUL!"
    echo "========================================"
    echo ""
    
    # Display file info
    FILE_SIZE=$(du -h "$OUTPUT_FILE" | cut -f1)
    
    echo "Output file: $OUTPUT_FILE"
    echo "File size: $FILE_SIZE"
    echo "Version: $VERSION"
    echo ""
    echo "The extension is ready for submission to Firefox Add-ons!"
    
else
    cd ..
    echo ""
    echo "ERROR: Build failed!"
    exit 1
fi
